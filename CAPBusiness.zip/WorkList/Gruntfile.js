module.exports = function (grunt) {
	"use strict";
	grunt.loadNpmTasks("@sap/grunt-sapui5-bestpractice-build");

	//	eslint - f jslint - xml jslintOutput.xml;

	grunt.config.merge({
		compatVersion: "1.71",
		eslint: {
			options: {
				outputFile: "jslintOutput.xml"
			}
		}
	});

	grunt.registerTask("default", [
		"lint"
	]);

};