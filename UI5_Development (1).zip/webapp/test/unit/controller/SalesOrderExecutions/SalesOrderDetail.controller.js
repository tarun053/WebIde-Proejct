sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"com/sap/sales/view/SalesOrderExecutions/SalesOrderDetail.controller"
], function(JSONModel, SalesOrderDetailController) {
	"use strict";
	var osalesDetailController;
	//CreateMethod(JSON)
	QUnit.module("SalesOrderDetail - validatePersonnelNumber", {
		setup: function() {
			//Controller Under Test
			this.oModel = new JSONModel({});
			osalesDetailController = new SalesOrderDetailController(this.oModel, function() {});
		}
	});

	function validatePersonnelNumberTestCase(assert,personnelNo, fExpected) {
		// pass the passed personnel number
		var fCreate = osalesDetailController.validatePersonnelNumber(personnelNo);
		// Assert
		assert.equal(fCreate, fExpected, personnelNo.concat(" has been validated."));
	}

	QUnit.test("Valid Personnel Number", function(assert) {
	  validatePersonnelNumberTestCase.call(this, assert, "12345678910", true);
/*	//For UT to be failed line 26 should be uncommented and line 24 commented and vice-verca. */
  // validatePersonnelNumberTestCase.call(this, assert, "123456", true);
	});
	QUnit.test("Invalid Personnel Number", function(assert) {
		validatePersonnelNumberTestCase.call(this, assert, "123456", false);
	});
});