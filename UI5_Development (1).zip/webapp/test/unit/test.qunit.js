sap.ui.define([
		"test/unit/controller/SalesOrderExecutions/SalesOrderDetail.controller"
	], function() { "use strict"; });