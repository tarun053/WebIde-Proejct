sap.ui.define([
	"sap/ui/Device",
	"com/sap/sales/util/Controller",
	"com/sap/sales/dev/devapp",
	"com/sap/sales/util/Formatter",
	"com/sap/sales/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Device, Controller, devapp, Formatter, BaseController, JSONModel, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("com.sap.sales.view.SalesOrderExecutions.SalesOrderMaster", {
		/**
		 * Event handler for the master search field. Applies current
		 * filter value and triggers a new search. If the search field's
		 * 'refresh' button has been pressed, no new search is triggered
		 * and the list binding is refresh instead.
		 */
		gotoHome: function() {
			this.getRouter().navTo("main");
		},
		onSearch: function() {
			// add filter for search
			var filters = [];
			var searchString = this.getView().byId("searchField").getValue();
			if (searchString && searchString.length > 0) {
				filters = [new sap.ui.model.Filter("Orderid", sap.ui.model.FilterOperator.Contains, searchString)];
			}

			// update list binding
			var list = this.getView().byId("SOList");
			list.getBinding("items").filter(filters);
			this._selectedItemIdx = list.indexOfItem(list.getSelectedItem());
		},

		onErrorBTVisible: function(errCount) {
			var bShow = false;
			if (errCount > 0) {
				bShow = true;
			}

			return bShow;
		},

		onErrorPress: function() {
			var oEventBus = this.getEventBus();
			oEventBus.publish("OfflineStore", "OpenErrDialog");
		},
		/**
		 * AddItem button handler
		 */
		addItem: function() {
			//	debugger;
			var model = this.getView().getModel();
			if (model.hasPendingChanges() || model.newEntryContext) {
				this.openCancelConfirmDialog();
				this._onConfirmAction = this.executeAddItem;
			} else {
				this.executeAddItem();
			}
		},
		/**
		 * open cancelConfirmDialog
		 */
		openCancelConfirmDialog: function() {
			if (!this._cancelConfirmDialog) {
				var id = this.getView().getId();
				var frgId = id + "-_cancelConfirmDialog";
				this._cancelConfirmDialog = sap.ui.xmlfragment(frgId, "com.sap.kapsales.view.CancelConfirmDialog", this);
				this.getView().addDependent(this._cancelConfirmDialog);
			}
			this._cancelConfirmDialog.open();
		},
		/**
		 * add a new record to offline store
		 */
		executeAddItem: function() {
			//	debugger;
			var oEventBus = this.getEventBus();
			oEventBus.publish("Master", "AddItem");
			//var oList = this.getView().byId("SOList");
			//var bindingPath = oList.getBinding("items").getPath();

			//var bReplace = Device.system.phone ? false : true;
			this.getRouter().navTo("object", {
				objectId: "AddItem"
			}, true);
		},
		onInit: function() {

			//	debugger;
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

			var oList = this.getView().byId("SOList"),
				oViewModel = this._createViewModel(),
				// Put down master list's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the master list is
				// taken care of by the master list itself.
				iOriginalBusyDelay = oList.getBusyIndicatorDelay();

			this._oList = oList;
			// keeps the filter and search state
			this._oListFilterState = {
				aFilter: [],
				aSearch: []
			};

			this.getView().setModel(oViewModel, "masterView");
			this.oInitialLoadFinishedDeferred = jQuery.Deferred();
			var oEventBus = this.getEventBus();

			this.getView().byId("SOList").attachEventOnce("updateFinished", function() {
				this.oInitialLoadFinishedDeferred.resolve();
				oEventBus.publish("Master", "InitialLoadFinished", {
					oListItem: this.getView().byId("SOList").getItems()[0]
				});
			}, this);

			oEventBus.subscribe("Detail", "TabChanged", this.onDetailTabChanged, this);
			//on phones, we will not have to select anything in the list so we don't need to attach to events
			if (Device.system.phone) {
				return;
			}
			oList.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for the list
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			this.getView().addEventDelegate({
				onBeforeFirstShow: function() {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});

			//	this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);

			oEventBus.subscribe("Detail", "Changed", this.onDetailChanged, this);
			oEventBus.subscribe("Detail", "NotFound", this.onNotFound, this);
			oEventBus.subscribe("Detail", "Cancelled", this.onDetailChangeCancelled, this);
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)

			this.getRouter().getRoute("salesitemdetails").attachPatternMatched(this._onMasterMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);

		},
		onNotFound: function() {
			this.getView().byId("SOList").removeSelections();
		},
		/**
		 * Detail cancel event handler, reset selected item and show detail view
		 * @param{String} sChanel event channel name
		 * @param{String} sEvent event name
		 * @param{Object} oData event data object
		 */
		onDetailChangeCancelled: function() {
			var list = this.getView().byId("SOList");
			var listItems = list.getItems();
			var selectedItem = list.getSelectedItem() ? list.getSelectedItem() : listItems[0];
			if (selectedItem) {
				list.setSelectedItem(selectedItem);
				this.showDetail(selectedItem);
			}
		},

		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 */
		showDetail: function(oItem) {
			var bReplace = !Device.system.phone;
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Orderid")
			}, bReplace);
		},

		onDetailChanged: function(sChanel, sEvent, oData) {
			var sProductPath = oData.sProductPath;
			//Wait for the list to be loaded once
			this.waitForInitialListLoading(function() {
				var oList = this.getView().byId("SOList");

				var oSelectedItem = oList.getSelectedItem();
				// the correct item is already selected
				if (oSelectedItem && oSelectedItem.getBindingContext().getPath() === sProductPath) {
					return;
				}

				var aItems = oList.getItems();

				for (var i = 0; i < aItems.length; i++) {
					if (aItems[i].getBindingContext().getPath() === sProductPath) {
						oList.setSelectedItem(aItems[i], true);
						break;
					}
				}
			});
		},
		/**
		 * If the master route was hit (empty hash) we have to set
		 * the hash to to the first item in the list as soon as the
		 * listLoading is done and the first item in the list is known
		 * @private
		 */
		_onMasterMatched: function() {
			//	debugger;
			this.getOwnerComponent().oListSelector.oWhenListLoadingIsDone.then(
				function(mParams) {
					if (mParams.list.getMode() === "None") {
						return;
					}
					var sObjectId = mParams.firstListitem.getBindingContext().getProperty("Orderid");
					this.getRouter().navTo("object", {
						objectId: sObjectId
					}, true);
				}.bind(this),
				function(mParams) {
					if (mParams.error) {
						return;
					}
					//this.getRouter().getTargets().display("detailNoObjectsAvailable");
				}.bind(this)
			);
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		_createViewModel: function() {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				title: this.getResourceBundle().getText("masterTitleCount", [0]),
				noDataText: this.getResourceBundle().getText("masterListNoDataText"),
				sortBy: "Orderid",
				groupBy: "None"
			});
		},

		gotoSearch: function() {
			sap.ui.getCore().getEventBus().publish("nav", "to", {
				viewId: "SalesOrderSearch",
				viewPackage: "com.accenture.directsales.views",
				viewName: "SalesOrderSearch",
				options: {
					//navType : "both"
					navType: "detail"
				}
			});
		},

		onSelectionChange: function(oEvent) {
			// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
			this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
		},
		_showDetail: function(oItem) {
			var bReplace = !Device.system.phone;
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Orderid")
			}, bReplace);
		},

		onListItemPress: function(evt) {
			var context = evt.getSource().getSelectedItem().getBindingContext().getProperty();
			var orderid = context.Orderid;

			//	var items = oList.getItems();
			//	oList.setSelectedItem(items[0]);

			sap.ui.getCore().byId('salesdetails').bindElement("/SOItems( '" + orderid + "' )");
			/*	var context = evt.getSource().getSelectedItem().getBindingContext().getProperty();
			var orderid = context.Orderid;
			this.odataModel.read("/SOItems?$filter= OrderId eq '"+orderid+ "'",
         null,  
         null,  
         false,  
         function(oData, oResponse){  
         	oData.DocumentType = context.Documenttype;
         		oData.OrderId = context.Orderid;
         	oData.CustomerId = context.Customerid;
         	oData.SalesOrg = context.Salesorg;
         	
         // create JSON model  
         var oODataJSONModel =  new sap.ui.model.json.JSONModel();  
        oODataJSONModel.setData(oData);  
       // console.log(oODataJSONModel);
        sap.ui.getCore().byId("salesitemdetails").setModel(oODataJSONModel);
        sap.ui.getCore().byId("salesitemdetails").bindElement("/");
         }            
        );*/

		},
		gotoCreate: function() {
			sap.ui.getCore().getEventBus().publish("nav", "to", {
				viewId: "SalesOrderCreate",
				viewPackage: "com.accenture.directsales.views",
				viewName: "SalesOrderCreate",
				options: {
					//navType : "both"
					navType: "detail"
				}
			});
		},

		/**
		 * refreshing offline store data
		 */
		refreshData: function() {
			var model = this.getView().getModel();
			if (model.hasPendingChanges() || model.newEntryContext) {
				this.openCancelConfirmDialog();
				this._onConfirmAction = jQuery.proxy(function() {
					if (devapp.isLoaded) {
						if (devapp.isOnline) {
							var oEventBus = this.getEventBus();
							oEventBus.publish("OfflineStore", "Refreshing");
						} else {
							model.refresh();
						}
					} else {
						model.refresh();
					}
				}, this);
			} else if (devapp.isLoaded) {
				if (devapp.isOnline) {
					var oEventBus = this.getEventBus();
					oEventBus.publish("OfflineStore", "Refreshing");
				} else {
					model.refresh();
				}
			} else {
				model.refresh();
			}
		}

	});

});