sap.ui.define([
	"sap/ui/Device",
	"com/sap/sales/util/Controller",
	"com/sap/sales/dev/devapp",
	"com/sap/sales/controller/BaseController"
], function(Device, Controller, devapp,BaseController) {
	"use strict";

	return BaseController.extend("com.sap.sales.view.SalesOrderExecutions.SplitApp", {
onInit:function() {

/*	var page = sap.ui.view({id:"salesmaster", viewName:"com.sap.sales.view.SalesOrderExecutions.SalesOrderMaster", type:sap.ui.core.mvc.ViewType.XML});
	this.getView().byId("salesApp").addPage(page,true);
	
		var page = sap.ui.view({id:"salesitemdetails", viewName:"com.sap.sales.view.SalesOrderExecutions.SalesOrderDetail", type:sap.ui.core.mvc.ViewType.XML});
	this.getView().byId("salesApp").addPage(page,false);*/
//console.log("in");
//debugger;
this.getRouter().navTo("salesitemdetails");
}

});
});