sap.ui.define([
	"sap/ui/Device",
	"com/sap/sales/util/Controller",
	"com/sap/sales/dev/devapp",
	"sap/ui/model/json/JSONModel",
	"com/sap/sales/controller/BaseController", "com/sap/sales/util/Formatter", "sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Device, Controller, devapp, JSONModel, BaseController, Formatter, MessageBox, Filter, FilterOperator) {
	"use strict";
	//var n = 99;
	return BaseController.extend("com.sap.sales.view.SalesOrderExecutions.SalesOrderDetail", {

		/**
		 * confirm delete handler
		 */
		confirmDelete: function() {
			if (this._deleteConfirmDialog) {
				this._deleteConfirmDialog.close();
			}
			if (this.getView().getBindingContext()) {
				var model = this.getView().getModel();
				if (model) {
					this.getView().setBusy(true);
					// model.remove(this.getView().getBindingContext().getPath(), {
					// 	success: jQuery.proxy(function(oData, oResponse) {
					// 		this.getView().setBusy(false);
					// 		this.openDialog("i18n>deleteSuccess");
					// 		if (Device.system.phone) {
					// 			this.onNavBack();
					// 		}
					// 	}, this),
					// 	error: jQuery.proxy(function(error) {
					// 		this.getView().setBusy(false);
					// 		//this.openDialog("i18n>deleteFailed");
					// 		var msg = error;
					// 		if (typeof(error) === "object" && error.response && error.response.body) {
					// 			msg = error.response.body;
					// 		}
					// 		this._showServiceError(msg);
					// 	}, this)
					// });

					var oModel = this.getView().getModel();
					oModel.setUseBatch(true);
					var batchChanges = [];
					batchChanges.push(oModel.createBatchOperation("/SOHeaders('" + this.orderId + "')", "DELETE"));
					oModel.addBatchChangeOperations(batchChanges);
					oModel.submitBatch(function(data) {
						this.getView().setBusy(false);
						this.switchMode("read");
						this.getRouter().navTo("object", {
							"objectId": this.orderId
						});
					}.bind(this), function(err) {
						//alert("Error occurred ");
						this.switchMode("read");
						this.getRouter().navTo("object", {
							"objectId": this.orderId
						});
					});
				}
			}
			if (Device.system.phone) {
				this.openDialog("i18n>deleteSuccess");
			}
		},

		/**
		 * close deleteConfirmDialog
		 */
		closeDeleteConfirmDialog: function() {
			if (this._deleteConfirmDialog) {
				this._deleteConfirmDialog.close();
			}
		},

		/**
		 * close the general dialog
		 */
		closeDialog: function() {
			if (this._dialog) {
				this._dialog.close();
			}
		},
		/**
		 * cancelConfirmDialog "yes" button handler
		 */
		confirmCancel: function() {
			var model = this.getView().getModel();
			model.resetChanges();

			if (model.newEntryContext) { //need to tell the Master List to select previous selected
				var view = this.getView();
				view.setBindingContext(null);
			}

			this.switchMode("read");
			if (Device.system.phone) {
				this.getRouter().myNavBack("salesitemdetails");
			} else {
				this.getEventBus().publish("Detail", "Cancelled");
			}
			this.closeCancelConfirmDialog();
		},
		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 */
		showDetail: function(oItem) {
			// If we're on a phone, include nav in history; if not, don't.
			var bReplace = Device.system.phone ? false : true;
			this.getRouter().navTo("detail", {
				from: "master",
				entity: oItem.getBindingContext().getPath().substr(1),
				tab: this.sTab
			}, bReplace);
		},

		/**
		 * close cancelConfirmDialog
		 */
		closeCancelConfirmDialog: function() {
			if (this._cancelConfirmDialog) {
				this._cancelConfirmDialog.close();
			}
		},

		//Begin of change 21/9
		/**
		 * open Add SO Items Dialog
		 *@param{object} oEvent instance of event being passed
		 */
		onOpenSOItems: function(oEvent) {
			if (!this._addSOItemsDialog) {
				this._addSOItemsDialog = sap.ui.xmlfragment("com.sap.sales.view.SalesOrderExecutions.SOItems", this);
				this.getView().addDependent(this._addSOItemsDialog);
			}
			this._addSOItemsDialog.open();

			var prefixId = this.getView().getId() + "detailCreateMode--";
			var soItemJSON = {
				"Item": "",
				"Material": "",
				"Description": "",
				"Plant": "",
				"Quantity": "",
				"UoM": "",
				"Value": "",
				"Currency": ""
			};
			this.soItemsMode = "create";
			if (oEvent.oSource.getId().indexOf(prefixId + "idSOItemsTbl") !== -1) {
				this.soItemsMode = "edit";
				var sourceId = oEvent.oSource.getId();
				// var allSOItems = sap.ui.getCore().byId(prefixId + "idSOItemsTbl").getModel("soItemsTable").oData.SOItems;
				var allSOItems = sap.ui.getCore().byId(prefixId + "idSOItemsTbl").getItems();
				this.selectedSOItemIndex = parseInt(sourceId.charAt(sourceId.length - 1), 10);
				var columnData = allSOItems[this.selectedSOItemIndex].getCells();
				soItemJSON = {
					"Item": columnData[0].getText(),
					"Material": columnData[1].getText(),
					"Description": columnData[2].getText(),
					"Plant": columnData[3].getText(),
					"Quantity": columnData[4].getText().split(" ")[0],
					"UoM": columnData[4].getText().split(" ")[1],
					"Value": columnData[5].getText().split(" ")[1],
					"Currency": columnData[5].getText().split(" ")[0]
				};
				// soItemJSON = allSOItems[this.selectedSOItemIndex];
			}

			var soItemsModel = new JSONModel(soItemJSON);
			sap.ui.getCore().byId("idSOItemsForm").setModel(soItemsModel, "soItemsModel");
		},
		/**
		 * cancel Add SO Items Dialog
		 */
		onCancelSOItems: function() {
			this._addSOItemsDialog.close();
		},

		/**
		 * save SO Items 
		 */
		onSaveSOItems: function() {
			var prefixId = this.getView().getId() + "detailCreateMode--";
			var that = this;
			var newSOItemJSON = sap.ui.getCore().byId("idSOItemsForm").getModel("soItemsModel").oData;
			if (this.soItemsMode === "create") {
				this.createSOItemsArray.push(newSOItemJSON);
			} else {
				this.createSOItemsArray[this.selectedSOItemIndex] = newSOItemJSON;
			}
			// this.createSOItemsArray.push(newSOItemJSON);
			var soItemsCreateModel = new JSONModel();

			soItemsCreateModel.setData({
				"SOItems": this.createSOItemsArray
			});

			sap.ui.getCore().byId(prefixId + "idSOItemsTbl").setModel(soItemsCreateModel, "soItemsTable");
			sap.ui.getCore().byId(prefixId + "idSOItemsTbl").getModel("soItemsTable").refresh();
			this.onCancelSOItems();
			if (this.soItemsMode === "edit") {
				var querySet = "/SOItems(OrderId='" + this.orderId + "',Item='" + newSOItemJSON.Item + "')";
				var model = that.getView().getModel();
				var etag = model.getProperty(querySet + "/__metadata").etag;
				var payload = {
					"OrderId": that.orderId,
					"Item": newSOItemJSON.Item,
					"Material": newSOItemJSON.Material,
					"Plant": newSOItemJSON.Plant
				};
				//Service call to update SO Item...
				this.getView().setBusy(true);
				model.update(querySet, payload, {
					eTag: etag,
					success: jQuery.proxy(function(oData, oResponse) {
						if (oResponse && oResponse.statusCode === 204) { // 201 == Created
							that.getView().setBusy(false);
							that.openDialog("i18n>saveSuccess");
							this.switchMode("read");
							if (oData && oData.__metadata && oData.__metadata.id) {
								var idx = oData.__metadata.id.lastIndexOf("/");
								var bindingPath = oData.__metadata.id.substring(idx);
								this.getRouter().navTo("object", {
									entity: bindingPath.substr(1)
								}, true);
							}
						}
					}, this),
					error: jQuery.proxy(function(err) {
						if (err.response.statusCode === 500) {
							that.openDialog("i18n>saveSuccess");
							that.switchMode("read");
						}
						that.getView().setBusy(false);

					}, this)
				});
				//Begin of change 21/9
				// var oBinding = sap.ui.getCore().byId("__component0---salesdetailsdetailReadMode--idSOItemsList").getBinding("items");
				// var aFilter = [];
				// aFilter.push(new Filter("OrderId", FilterOperator.Contains, this.sObjectId));
				// // apply filter. an empty filter array simply removes the filter
				// // which will make all entries visible again
				// oBinding.filter(aFilter);
				//End of change 21/9				
			}
		},
		//End of change 21/9

		/**
		 * open a general dialog
		 * @param{String} sI18nKeyword i18n keyword 
		 */
		openDialog: function(sI18nKeyword) {
			if (!this._dialog) {
				var id = this.getView().getId();
				var frgId = id + "-msgDialog";
				this._dialog = sap.ui.xmlfragment(frgId, "com.sap.sales.view.SalesOrderExecutions.MsgDialog", this);
				this.getView().addDependent(this._dialog);
				this._dialogText = sap.ui.core.Fragment.byId(frgId, "dialogText");
			}

			this._dialogText.bindProperty("text", sI18nKeyword);
			this._dialog.open();
		},

		confirmEdit: function() {
			var that = this,
				oModel = this.getModel();

			// abort if the  model has not been changed
			if (!oModel.hasPendingChanges()) {
				MessageBox.information(
					this._oResourceBundle.getText("noChangesMessage"), {
						id: "noChangesInfoMessageBox",
						styleClass: that.getOwnerComponent().getContentDensityClass()
					}
				);
				return;
			}
			this.getModel("appView").setProperty("/busy", true);
			if (this._oViewModel.getProperty("/mode") === "edit") {
				// attach to the request completed event of the batch
				oModel.attachEventOnce("batchRequestCompleted", function(oEvent) {
					if (that._checkIfBatchRequestSucceeded(oEvent)) {
						that._fnUpdateSuccess();
					} else {
						that._fnEntityCreationFailed();
						MessageBox.error(that._oResourceBundle.getText("updateError"));
					}
				});
			}
			oModel.submitChanges();
		},

		/**
		 * detai view save button handler
		 */
		saveChanges: function() {

			var model = this.getView().getModel();
			//Begin of change 21/09

			var prefixId = this.getView().getId() + "detailCreateMode--";

			if (model.hasPendingChanges() || model.newEntryContext) {

				this.getView().setBusy(true);
				//Begin of change 21/09

				if (model.newEntryContext) {
					this.getView().setBusy(true);
					//++n;
					//Begin of change 21/09
					if (!this.num) {
						this.num = 100;
					}
					this.num = this.num + 1;
					var payload = {
						"Orderid": "Order" + this.num,
						"Employeenumber": sap.ui.getCore().byId(prefixId + "input2").getValue(),
						"Documenttype": sap.ui.getCore().byId(prefixId + "input3").getValue(),
						"Customerid": sap.ui.getCore().byId(prefixId + "input5").getValue(),
						"Salesorg": sap.ui.getCore().byId(prefixId + "input6").getValue(),
						"Distchannel": sap.ui.getCore().byId(prefixId + "input7").getValue(),
						"Division": sap.ui.getCore().byId(prefixId + "input8").getValue(),
						"Ordervalue": sap.ui.getCore().byId(prefixId + "input9").getValue(),
						"Currency": sap.ui.getCore().byId(prefixId + "input10").getValue(),
						"Doctypedesc": sap.ui.getCore().byId(prefixId + "input11").getValue(),
						"CollectiveNo": sap.ui.getCore().byId(prefixId + "input12").getValue(),
						"Shiptopartycharacter": sap.ui.getCore().byId(prefixId + "input13").getValue(),
						"ShiptopartyPOdate": sap.ui.getCore().byId(prefixId + "input14").getValue(),
						"ShiptoPartyPO": sap.ui.getCore().byId(prefixId + "input15").getValue(),
						//"NoofContacts": sap.ui.getCore().byId(prefixId + "input16").getValue(),
						"SupplementPO": sap.ui.getCore().byId(prefixId + "input17").getValue(),
						"PhoneNO": sap.ui.getCore().byId(prefixId + "input18").getValue(),
						"UrRef": sap.ui.getCore().byId(prefixId + "input19").getValue(),
						"name": sap.ui.getCore().byId(prefixId + "input20").getValue(),
						"LastCustContactDate": sap.ui.getCore().byId(prefixId + "input21").getValue(),
						"CustPurchaseOrdertype": sap.ui.getCore().byId(prefixId + "input22").getValue(),
						"CustPurchaseOrdDate": sap.ui.getCore().byId(prefixId + "input23").getValue(),
						"CustPurchaseOrderNo": sap.ui.getCore().byId(prefixId + "input24").getValue()
					};

					var SOItems = sap.ui.getCore().byId(prefixId + "idSOItemsTbl").getModel("soItemsTable").oData.SOItems;
					var oModel = this.getView().getModel();
					oModel.setHeaders({
						"Content-Id": "100"
					});
					oModel.setUseBatch(true);
					var batchChanges = [];
					batchChanges.push(oModel.createBatchOperation("/SOHeaders", "POST", payload));
					SOItems.forEach(function(sItem) {
						batchChanges.push(oModel.createBatchOperation("$100/SOItems", "POST", sItem));
					}, this);
					oModel.addBatchChangeOperations(batchChanges);

					oModel.submitBatch(function(data) {
						this.getView().setBusy(false);
						this.switchMode("read");
						this.getRouter().navTo("object", {
							"objectId": this.orderId
						});
					}.bind(this), function(err) {
						//alert("Error occurred ");
						this.switchMode("read");
						this.getRouter().navTo("object", {
							"objectId": this.orderId
						});
					});

				} else {
					//	this.getView().setBusy(true);
					var that = this;
					var payload1 = {
						"Employeenumber": sap.ui.getCore().byId(prefixId + "input2").getValue(),
						"Documenttype": sap.ui.getCore().byId(prefixId + "input3").getValue(),
						"Customerid": sap.ui.getCore().byId(prefixId + "input5").getValue(),
						"Salesorg": sap.ui.getCore().byId(prefixId + "input6").getValue(),
						"Distchannel": sap.ui.getCore().byId(prefixId + "input7").getValue(),
						"Division": sap.ui.getCore().byId(prefixId + "input8").getValue(),
						"Ordervalue": sap.ui.getCore().byId(prefixId + "input9").getValue(),
						"Currency": sap.ui.getCore().byId(prefixId + "input10").getValue(),
						"Doctypedesc": sap.ui.getCore().byId(prefixId + "input11").getValue(),
						"CollectiveNo": sap.ui.getCore().byId(prefixId + "input12").getValue(),
						"Shiptopartycharacter": sap.ui.getCore().byId(prefixId + "input13").getValue(),
						"ShiptopartyPOdate": sap.ui.getCore().byId(prefixId + "input14").getValue(),
						"ShiptoPartyPO": sap.ui.getCore().byId(prefixId + "input15").getValue(),
						//	"NoofContacts": sap.ui.getCore().byId(prefixId + "input16").getValue(),
						"SupplementPO": sap.ui.getCore().byId(prefixId + "input17").getValue(),
						"PhoneNO": sap.ui.getCore().byId(prefixId + "input18").getValue(),
						"UrRef": sap.ui.getCore().byId(prefixId + "input19").getValue(),
						"name": sap.ui.getCore().byId(prefixId + "input20").getValue(),
						"LastCustContactDate": sap.ui.getCore().byId(prefixId + "input21").getValue(),
						"CustPurchaseOrdertype": sap.ui.getCore().byId(prefixId + "input22").getValue(),
						"CustPurchaseOrdDate": sap.ui.getCore().byId(prefixId + "input23").getValue(),
						"CustPurchaseOrderNo": sap.ui.getCore().byId(prefixId + "input24").getValue()

					};
					payload1.Orderid = this.orderId;
					model.update("/SOHeaders('" + this.orderId + "')", payload1, {
						success: jQuery.proxy(function(oData, oResponse) {
							if (oResponse && oResponse.statusCode === 204) { // 201 == Created
								this.getView().setBusy(false);
								that.openDialog("i18n>saveSuccess");
								this.switchMode("read");
								if (oData && oData.__metadata && oData.__metadata.id) {
									var idx = oData.__metadata.id.lastIndexOf("/");
									var bindingPath = oData.__metadata.id.substring(idx);
									this.getRouter().navTo("object", {
										entity: bindingPath.substr(1)
									}, true);
								}
							}
						}, this),
						error: jQuery.proxy(function(err) {
							//alert("Error");
							this.getView().setBusy(false);
						}, this)
					});
				}
				if (Device.system.phone) {
					this.switchMode("read");
					this.getRouter().navTo("salesorders");
				}
				// 		this.getView().getModel().refresh();
				// 		//sap.ui.getCore().byId("__xmlview1---SalesMaster--refreshData");
				// // 		var bReplace = Device.system.phone ? false : true;
				// // this.getRouter().navTo("master", {
				// // 	from: "detail",
				// // 	tab: this.sTab
				// // }, bReplace);
				// 	this.onNavBack();

				// 		var model = this.getView().getModel();
				// if (model.hasPendingChanges() || model.newEntryContext) {
				// 	//Sap.ui.core.byID(--component00--SalesMaster---refreshData).openCancelConfirmDialog();
				// 		//sap.ui.getCore().byId("")
				// 	this._onConfirmAction = jQuery.proxy(function() {
				// 		if (devapp.isLoaded) {
				// 			if (devapp.isOnline) {
				// 				var oEventBus = this.getEventBus();
				// 				oEventBus.publish("OfflineStore", "Refreshing");
				// 			} else {
				// 				model.refresh();
				// 			}
				// 		} else {
				// 			model.refresh();
				// 		}
				// 	}, this);
				// } else {
				// 	if (devapp.isLoaded) {
				// 		if (devapp.isOnline) {
				// 			var oEventBus = this.getEventBus();
				// 			oEventBus.publish("OfflineStore", "Refreshing");
				// 		} else {
				// 			model.refresh();
				// 		}
				// 	} else {
				// 		model.refresh();
				// 	}
				// } 
				//}
			}
			//Begin of change 21/9
			// var oBinding = sap.ui.getCore().byId("__component0---salesdetailsdetailReadMode--idSOItemsList").getBinding("items");
			// var aFilter = [];
			// aFilter.push(new Filter("OrderId", FilterOperator.Contains, this.sObjectId));
			// // apply filter. an empty filter array simply removes the filter
			// // which will make all entries visible again
			// oBinding.filter(aFilter);
			//End of change 21/9			
		},
		/**
		 * Shows a {@link sap.m.MessageBox} when a service call has failed.
		 * Only the first error message will be display.
		 * @param {string} sDetails a technical error to be displayed on request
		 * @private
		 */
		_showServiceError: function(sDetails) {
			MessageBox.error(
				this._sErrorText, {
					id: "serviceErrorMessageBox",
					details: sDetails,
					styleClass: this.getOwnerComponent().getContentDensityClass(),
					actions: [MessageBox.Action.CLOSE]
				});
		},
		/**
		 * detai view edit button handler
		 */
		editItem: function() {
			this.switchMode("edit");
		},

		/**
		 * detai view delete button handler
		 */
		deleteItem: function() {
			this.openDeleteConfirmDialog();
		},
		/**
		 * open deleteConfirmDialog
		 */
		openDeleteConfirmDialog: function() {
			if (!this._deleteConfirmDialog) {
				var id = this.getView().getId();
				var frgId = id + "-_deleteConfirmDialog";
				this._deleteConfirmDialog = sap.ui.xmlfragment(frgId, "com.sap.sales.view.DeleteConfirmDialog", this);
				this.getView().addDependent(this._deleteConfirmDialog);
			}
			this._deleteConfirmDialog.open();
		},

		/**
		 * cancel edit handler
		 */
		cancelEdit: function() {
			var model = this.getView().getModel();
			if (model.hasPendingChanges() || model.newEntryContext) {
				this.openCancelConfirmDialog();
			} else {
				this.switchMode("read");
			}
			// //Begin of change 21/9
			var oBinding = sap.ui.getCore().byId("__component0---salesdetailsdetailReadMode--idSOItemsList").getBinding("items");
			var aFilter = [];
			aFilter.push(new Filter("OrderId", FilterOperator.EQ, this.sObjectId));
			// apply filter. an empty filter array simply removes the filter
			// which will make all entries visible again
			oBinding.filter(aFilter);
			// //End of change 21/9			
		},
		/**
		 * open cancelConfirmDialog
		 */
		openCancelConfirmDialog: function() {
			if (!this._cancelConfirmDialog) {
				var id = this.getView().getId();
				var frgId = id + "-_cancelConfirmDialog";
				this._cancelConfirmDialog = sap.ui.xmlfragment(frgId, "com.sap.sales.view.CancelConfirmDialog", this);
				this.getView().addDependent(this._cancelConfirmDialog);
			}
			this._cancelConfirmDialog.open();
		},
		onInit: function() {
			//console.log("detail");
			//debugger;

			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				lineItemListTitle: "Items"
			});

			this.oInitialLoadFinishedDeferred = jQuery.Deferred();
			this._bMessageOpen = false;
			this._sErrorText = this.getResourceBundle().getText("errorText");

			if (!this._detailReadMode) {
				this._detailReadModeFragmentName = this.getView().getId() + "detailReadMode";
				this._detailReadMode = sap.ui.xmlfragment(this._detailReadModeFragmentName,
					"com.sap.sales.view.SalesOrderExecutions.SalesOrderRead", this);
				this.switchMode("read");
			}
			if (!this._detailEditMode) {
				this._detailEditModeFragmentName = this.getView().getId() + "detailEditMode";
				this._detailEditMode = sap.ui.xmlfragment(this._detailEditModeFragmentName,
					"com.sap.sales.view.SalesOrderExecutions.SalesOrderEdit", this);
			}

			if (!this._detailCreateMode) {
				this._detailCreateModeFragmentName = this.getView().getId() + "detailCreateMode";
				this._detailCreateMode = sap.ui.xmlfragment(this._detailCreateModeFragmentName,
					"com.sap.sales.view.SalesOrderExecutions.SalesOrderCreate", this);
			}

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
			//	this.getRouter().getRoute("detail").attachPatternMatched(this.onRouteMatched, this);

			this.getView().setModel(oViewModel, "detailView");

		},
		/**
		 * online icon formatter
		 *@param{boolean} bIsOffline first boolean	
		 *@param{boolean} bIsPhone second boolean
		 *@returns{boolean} returns boolean value
		 */
		onlineIconVisible: function(bIsOffline, bIsPhone) {
			return bIsPhone && bIsOffline;
		},

		/**
		 * Detail view RoutePatternMatched event handler 
		 * @param{sap.ui.base.Event} oEvent router pattern matched event object
		 */
		onRouteMatched: function(oEvent) {
			//	debugger;
			var oParameters = oEvent.getParameters();

			jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(function() {
				var oView = this.getView();

				var sEntityPath = "/" + oParameters.arguments.entity;

				if (oParameters.arguments.tab === "AddItem") {
					var model = this.getView().getModel();
					var newEntry = model.createEntry(sEntityPath);
					this.switchMode("create");
					model.newEntryContext = newEntry;
					//clean bounded data object
					oView.unbindObject();
					//now set new binding context
					oView.setBindingContext(newEntry);
				} else {
					this.switchMode(this._sMode);
					this.bindView(sEntityPath);

					var oIconTabBar = sap.ui.core.Fragment.byId(this._fragmentName, "idIconTabBar");
					if (oIconTabBar) {
						oIconTabBar.getItems().forEach(function(oItem) {
							oItem.bindElement(Formatter.uppercaseFirstChar(oItem.getKey()));
						});

						// Which tab?
						var sTabKey = oParameters.arguments.tab;
						this.getEventBus().publish("Detail", "TabChanged", {
							sTabKey: sTabKey
						});

						if (oIconTabBar.getSelectedKey() !== sTabKey) {
							oIconTabBar.setSelectedKey(sTabKey);
						}
					}
				}
			}, this));

		},

		/**
		 * switch detail view among create, edit and read mode
		 * @param {String} sMode detail view mode name
		 */
		switchMode: function(sMode) {
			if (this._sMode !== "read") {
				var model = this.getView().getModel();
				if (model) {
					if (model.newEntryContext) {
						model.deleteCreatedEntry(model.newEntryContext);
						model.newEntryContext = null;
					}
					if (model.hasPendingChanges()) {
						model.resetChanges();
					}
				}
			}

			if (this._sMode === sMode) {
				return;
			}
			this._sMode = sMode;
			var view = this.getView();
			var page = view.byId("detailPage");
			//Begin of change 21/9
			var prefixIdCreate = this.getView().getId() + "detailCreateMode--";
			// if (sMode === "create") {
			// 	this.createSOItemsArray = [];
			// 	this._fragmentName = this._detailCreateModeFragmentName;
			// 	if (page.getContent()[0] !== this._detailCreateMode) {
			// 		page.removeAllContent();
			// 		page.addContent(this._detailCreateMode);
			// 	}
			// 	view.byId("saveButton").setVisible(true);
			// 	view.byId("cancelButton").setVisible(true);
			// 	view.byId("editButton").setVisible(false);
			// 	view.byId("deleteButton").setVisible(false);
			// } else if (sMode === "edit") {
			// 	this._fragmentName = this._detailEditModeFragmentName;
			// 	if (page.getContent()[0] !== this._detailEditMode) {
			// 		page.removeAllContent();
			// 		page.addContent(this._detailEditMode);
			// 	}
			// 	view.byId("saveButton").setVisible(true);
			// 	view.byId("cancelButton").setVisible(true);
			// 	view.byId("editButton").setVisible(false);
			// 	view.byId("deleteButton").setVisible(false);
			// } 

			if (sMode === "create" || sMode === "edit") {
				sap.ui.getCore().byId(prefixIdCreate + "idBtnAddSOItems").setVisible(true);
				this.createSOItemsArray = [];
				var soItemsCreateModel = new JSONModel(this.createSOItemsArray);
				if (sMode === "edit") {
					sap.ui.getCore().byId(prefixIdCreate + "idBtnAddSOItems").setVisible(false);
					var soItems = sap.ui.getCore().byId(this.getView().getId() + "detailReadMode--idSOItemsList").getItems();
					for (var i = 0; i < soItems.length; i++) {
						var columnData = soItems[i].getCells();
						var temp = {
							"Item": columnData[0].getText(),
							"Material": columnData[1].getItems()[0].getText(),
							"Description": columnData[1].getItems()[1].getText(),
							"Plant": columnData[2].getText(),
							"Quantity": columnData[3].getText().split(" ")[0],
							"UoM": columnData[3].getText().split(" ")[1],
							"Value": columnData[4].getNumber(),
							"Currency": columnData[5].getText()
						};
						this.createSOItemsArray.push(temp);
					}
					soItemsCreateModel = new JSONModel();
					soItemsCreateModel.setData({
						"SOItems": this.createSOItemsArray
					});
				}
				sap.ui.getCore().byId(prefixIdCreate + "idSOItemsTbl").setModel(soItemsCreateModel, "soItemsTable");
				this._fragmentName = this._detailCreateModeFragmentName;
				if (page.getContent()[0] !== this._detailCreateMode) {
					page.removeAllContent();
					page.addContent(this._detailCreateMode);
				}
				view.byId("saveButton").setVisible(true);
				view.byId("cancelButton").setVisible(true);
				view.byId("editButton").setVisible(false);
				view.byId("deleteButton").setVisible(false);
			} else {
				this._sMode = sMode;
				this._fragmentName = this._detailReadModeFragmentName;
				if (page.getContent()[0] !== this._detailReadMode) {
					page.removeAllContent();
					page.addContent(this._detailReadMode);
				}
				view.byId("saveButton").setVisible(false);
				view.byId("cancelButton").setVisible(false);
				view.byId("editButton").setVisible(true);
				view.byId("deleteButton").setVisible(true);
			}
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.Orderid,
				sObjectName = oObject.Orderid,
				oViewModel = this.getView().getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},
		_onObjectMatched: function(oEvent) {

			//	debugger;
			var sObjectId = oEvent.getParameter("arguments").objectId;
			if (sObjectId !== "AddItem") {
				this.sObjectId = sObjectId;
				this.orderId = sObjectId;
			}
			var oView = this.getView();

			if (sObjectId === "AddItem") {
				var model = this.getView().getModel();
				var newEntry = model.createEntry("/SOHeaders");
				this.switchMode("create");
				model.newEntryContext = newEntry;
				//clean bounded data object
				oView.unbindObject();
				//now set new binding context
				oView.setBindingContext(newEntry);
				return;
			}
			this.switchMode(this._sMode);
			// //Begin of change 21/9
			var oBinding = sap.ui.getCore().byId("__component0---salesdetailsdetailReadMode--idSOItemsList").getBinding("items");
			var aFilter = [];
			aFilter.push(new Filter("OrderId", FilterOperator.EQ, this.sObjectId));
			// apply filter. an empty filter array simply removes the filter
			// which will make all entries visible again
			oBinding.filter(aFilter);
			// //End of change 21/9			
			var sObjectPath = this.getView().getModel().createKey("SOHeaders", {
				Orderid: sObjectId
			});
			this._bindView("/" + sObjectPath);

		},
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getView().getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},
		// 		Attachment: function() {
		// if(!this.attachment){
		// 			this.attachmentname = this.getView().getId() + "attachment";
		// 			this.attachment = sap.ui.xmlfragment(this.attachmentname, "com.sap.sales.view.SalesOrderExecutions.SalesOrderAttachment", this);
		// 			this.getView().addDependent(this.attachment);
		// }
		// // this.getView().addDependent(this.attachment);
		// //this.attachment.open();

		// this.attachment.open();
		// 		}
		// handleUploadPress: function(oEvent) {
		// 	var oFileUploader = this.getView().byId("fileUploader");
		// 	oFileUploader.upload();
		// },

		// handleFileChange: function(oEvent, oView) {

		////cordova
		// 		var oModel = this.getView().getModel();
		// 			var filename = oEvent.getParameters().files[0].name;
		// 						var Slugvalue = this.orderId + "/" + filename;
		// 							var _csrfToken = oModel.getSecurityToken()
		// 		var fileURL;
		// 		var options = new FileUploadOptions();
		// options.fileKey="file";
		// options.fileName="demo";
		// options.mimeType="text/plain";

		// var headers={'Slug':'Slugvalue', 'x-csrf-token':'_csrfToken'};

		// options.headers = headers;

		// var ft = new FileTransfer();
		// ft.onprogress = function(progressEvent) {
		//     if (progressEvent.lengthComputable) {
		//         loadingStatus.setPercentage(progressEvent.loaded / progressEvent.total);
		//     } else {
		//         loadingStatus.increment();
		//     }
		// };
		// ft.upload(fileURL, uri, win, fail, options);

		///cordova
		// 			var oModel = this.getView().getModel();
		// 			var _csrfToken = oModel.getSecurityToken()
		// // 			var filename = oEvent.getParameters().fileName;
		// 			var filename = oEvent.getParameters().files[0].name;
		// 						var Slugvalue = this.orderId + "/" + filename;
		// 						var oSlugHeaderToken = new sap.m.UploadCollectionParameter({
		// 							name: "Slug",
		// 							value: Slugvalue
		// 						});
		// 						oEvent.getSource().addHeaderParameter(oSlugHeaderToken);
		// 						var oHeaderToken = new sap.m.UploadCollectionParameter({
		// 							name: "x-csrf-token",
		// 							value: _csrfToken
		// 						});
		// 						oEvent.getSource().addHeaderParameter(oHeaderToken);
		// 						var oAccept = new sap.m.UploadCollectionParameter({
		// 							name: "accept",
		// 							value: "text/plain"
		// 						});
		// 						oEvent.getSource().addHeaderParameter(oAccept);
		// var filename = oEvent.getParameters().files[0].name;
		// var Slugvalue = "'" + this.orderId + "'" + "/" + "'" + filename + "'";
		// 			var sEntityset = "/SOAttachmentSet('" + this.orderId + "')/$value";
		// 			// // Sart of change by muthu
		// 			oModel.create("/SOAttachmentSet", null, {
		// 				headers: {
		// 					"X-CSRF-Token": "Fetch",
		// 					"SLUG":Slugvalue
		// 				},
		// 				success: function(oData, response) {
		// 						// var oUploadCollection = oEvent.getSource();
		// 						// var oCustomerHeaderToken = new UploadCollectionParameter({
		// 						// 	name: "x-csrf-token",
		// 						// 	value: _csrfToken
		// 						// });
		// 						// oUploadCollection.addHeaderParameter(oCustomerHeaderToken);

		// 						var header_xcsrf_token = response.headers["x-csrf-token"];
		// 						this.sCsrfToken = header_xcsrf_token;

		// 						var oHeaderToken = new sap.m.UploadCollectionParameter({
		// 							name: "X-CSRF-Token",
		// 							value: "Fetch"
		// 						});
		// 						oEvent.getSource().addHeaderParameter(oHeaderToken);
		// 						var filename = oEvent.getParameters().fileName;
		// 						var Slugvalue = "'" + this.orderId + "'" + "/" + "'" + filename + "'";
		// 						var oSlugHeaderToken = new sap.m.UploadCollectionParameter({
		// 							name: "SLUG",
		// 							value: Slugvalue
		// 						});
		// 						oEvent.getSource().addHeaderParameter(oSlugHeaderToken);
		// 						var oAccept = new sap.m.UploadCollectionParameter({
		// 							name: "accept",
		// 							value: "application/json"
		// 						});
		// 						oEvent.getSource().addHeaderParameter(oAccept);
		// 					}.bind(this)
		// 					// }
		// 			});

		//end of change by muthu  

		////Start of change by vicky

		// OData.request({
		// 		requestUri: "/sap/opu/odata/sap/ZDSE_APPLICATION_SRV",
		// 		method: "GET",
		// 		headers: {
		// 			"X-Requested-With": "XMLHttpRequest",
		// 			"Content-Type": "application/atom+xml",
		// 			"DataServiceVersion": "2.0",
		// 			"X-CSRF-Token": "Fetch"
		// 		}
		// 	}, function(data, response) {

		// 		var header_xcsrf_token = response.headers['x-csrf-token'];
		// 		var sCsrfToken = header_xcsrf_token;
		// 		console.log(">>>>>>>>>>>>  " + sCsrfToken);
		// 		var oHeaderToken = new sap.m.UploadCollectionParameter({
		// 			name: "X-CSRF-Token",
		// 			value: sCsrfToken
		// 		});

		// 		var oHeaderToken = new sap.m.UploadCollectionParameter({
		// 			name: "X-CSRF-Token",
		// 			value: sCsrfToken

		// 		});
		// oEvent.getSource().addHeaderParameter(oHeaderToken);
		// // 		// var uploadcollectionitem = this.getView().byId("fileUploader");

		// // var filename = oEvent.getParameters().files[0].name;
		// // var Slugvalue = "'" + this.orderId + "'" + "/" + "'" + filename + "'";
		// // // var mimetype=oEvent.getParameters().files[0].name.split(".")[1].toUpperCase();
		// // // var slugvalue=filedescription+"|"+objectkey+"|"+company+"|"+vertical+"|"+bussegment+"|"+region+"|"+department+"|"+circle+"|"+city+"|"+dipcode+"|"+fidocnumber+"|"+filename+"|"+mimetype;
		// // var oSlugHeaderToken = new sap.m.UploadCollectionParameter({
		// // 	name: "SLUG",
		// // 	value: Slugvalue
		// // });
		// // oEvent.getSource().addHeaderParameter(oSlugHeaderToken);
		// // var oAccept = new sap.m.UploadCollectionParameter({
		// // 	name: "accept",
		// // 	value: "application/json"

		// // });
		// // oEvent.getSource().addHeaderParameter(oAccept);

		// // },
		// // function(err) {
		// // 	that.getView().setBusy(false);
		// // 	MessageBox.error("Error has occured , please try again after some time");
		// });

		// },
		OnPressAttachment: function() {
			MessageBox.alert("attachment has clicked");
		},
		validatePersonnelNumber: function(personnelNumber) {
			var status;
			if (personnelNumber.toString().length > 9) {
				status = true;
			} else {
				status = false;
			}
			return status;
		},
		onValidate: function(oEvent) {
			if (!this.validatePersonnelNumber(oEvent.getSource().getValue())) {
				oEvent.getSource().setValueState("Error");
				MessageBox.error("Personnel number should be minimum 10 digits.");
			} else {
				oEvent.getSource().setValueState("Success");
			}
		}
	});

});