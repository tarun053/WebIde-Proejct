sap.ui.define([], function() {
	"use strict";

	var Formatter = {
		/**
		 * Upper the first character of giving string
		 * @param{String} sStr input string
		 * @returns {String}} the input string with the first uppercase character
		 */
		uppercaseFirstChar: function(sStr) {
			return sStr.charAt(0).toUpperCase() + sStr.slice(1);
		},
		formatdate: function(value) {
			if (value) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "MM-dd-yyyy"
				});
				return oDateFormat.format(new Date(value));
			} else {
				return value;
			}
		},
		//Begin of change 25/9/2017
		formatSOItemsQuantity: function(quantity, uom) {
			var val = quantity;
			if (quantity && quantity !== "" && uom && uom !== "") {
				val = quantity + " " + uom;
			}
			return val;
		},
		formatSOItemsValue: function(value, currency) {
				var val = value;
				if (value && value !== "" && currency && currency !== "") {
					val = currency + " " + value;
				}
				return val;
			}
			//End of change

	};
	return Formatter;

}, /* bExport= */ true);