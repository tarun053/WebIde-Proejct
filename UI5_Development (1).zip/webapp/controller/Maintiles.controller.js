sap.ui.define([
	"sap/ui/Device",
	"com/sap/sales/util/Controller",
	"com/sap/sales/dev/devapp",
	"com/sap/sales/controller/BaseController"
], function(Device, Controller, devapp,BaseController) {
	"use strict";

	return BaseController.extend("com.sap.sales.controller.Maintiles", {
		/**
		 * Called when the master list controller is instantiated. 
		 * It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 */
		onInit: function() {
		
		},
		onCustomer:function() {
			this.getRouter().navTo("customer");
			
			
		},
			onSales:function() {	
			this.getRouter().navTo("salesorders");	
		},
			onMaterial:function() {
				this.getRouter().navTo("material");
		}
		

		/**
		 * Master view RoutePatternMatched event handler 
		 * @param{sap.ui.base.Event} oEvent router pattern matched event object
		 */
	
	});
});