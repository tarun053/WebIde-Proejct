package example;


import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SeleniumTest {

	private static WebDriver driver;
	private String baseUrl;
	private static DesiredCapabilities capabilities;
	private static int screenCount = 0;
	private static boolean firstRun = true;
	/**
	 * 
	 * @throws Exception
	 */
	@BeforeTest
	public void beforeTest() throws Exception {
		//The Hub URL
		URL url = new URL("http://localhost:4444/wd/hub");
		URL testurl = new URL("http://10.35.20.233:4444/wd/hub");
		//Set the capability as per the platform. For LINUX based configure firefox.
		capabilities = setFirefoxCapabilityDetails();
		// Set the capability as per the platform. For local windows based configure chrome.
		//capabilities = setChromeCapabilityDetails();
		driver = new RemoteWebDriver(testurl, capabilities);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		baseUrl = "https://adop_user:Welcome1@10.35.20.212:8011";
		//Adding Negative AT
		//System.out.println(Hello);
		
	}

	@Test
	public void testAll() {
		
		//Getting the Application URL.
		// driver.get(baseUrl
		// 		+ "/sap/bc/ui5_ui5/sap/z_dirsalesapp/index.html?sap-client=200&sap-ui-language=EN&sap-ui-xx-devmode=true#");
		// assertTrue(isElementPresent(By.xpath("//span[@id='__page0-title-inner']")));
		
		// getScreenShot("Screen_" + (++screenCount));
		 //
		// Uncomment everything inside method this for netaive AT-FT Testing. Remember to comment once the testing is done. 
	 //  assertTrue(isElementPresent(By.xpath("//div[@id='__tile0-title']")));
	    
	 //   driver.findElement(By.xpath("//div[@id='__tile0-title']")).click();
	 //   assertTrue(isElementPresent(By.xpath("//div[@id='__item2-__xmlview1--SOList-0-content']")));
	 //  getScreenShot("Screen_" + (++screenCount));
	    
	    
		// driver.findElement(By.xpath("//button[@id='__button0']")).click();
	 // assertTrue(isElementPresent(By.xpath("//span[@id='__page0-title-inner']")));
	 //assertTrue(isElementPresent(By.xpath("//div[@id='__tile1-title']")));
	 //getScreenShot("Screen_" + (++screenCount));
	 //driver.findElement(By.xpath("//div[@id='__tile1-title']")).click();
	 //assertTrue(isElementPresent(By.xpath("//td[@id='__item3-__clone0_cell1']")));
	 //getScreenShot("Screen_" + (++screenCount));
	    
	 //   driver.findElement(By.xpath("//button[@id='__page1-navButton']")).click();
	 //  assertTrue(isElementPresent(By.xpath("//span[@id='__page0-title-inner']")));
	 //   assertTrue(isElementPresent(By.xpath("//div[@id='__tile2-title']")));
	 //   getScreenShot("Screen_" + (++screenCount));
	 //   driver.findElement(By.xpath("//div[@id='__tile2-title']")).click();
	 //   assertTrue(isElementPresent(By.xpath("//span[@id='__text78']")));
	 //   getScreenShot("Screen_" + (++screenCount));
		
	}


	@AfterTest
	public void afterTest() {
		driver.quit();
	}
	
	private void getScreenShot(String fileName) {
		//String path = "./target/screenshot/";
		String path = "./target/";
		try {
			if (firstRun) {
				FileUtils.cleanDirectory(new File(path));
			}
			File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			// now copy the screenshot to desired location using copyFile method.
			FileUtils.copyFile(src, new File(path + fileName + ".png"));
			firstRun = false;
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * Use this method when testing the script on selenium server.
	 * @return firefox capability
	 */
	private DesiredCapabilities setFirefoxCapabilityDetails(){
		DesiredCapabilities  capability = DesiredCapabilities.firefox(); 
		capability.setBrowserName("firefox");
		capability.setVersion("58.0.1");
		capability.setPlatform(Platform.LINUX);
		return capability;
	}
	
	/**
	 * Use this method when testing the script on local system.
	 * @return chrome capability
	 */
	private DesiredCapabilities setChromeCapabilityDetails() {
		DesiredCapabilities  capability = DesiredCapabilities.chrome(); 
		return capability;
	}
	
	private boolean isElementPresent(By by) {
	    try {
	      driver.findElement(by);
	      return true;
	    } catch (NoSuchElementException e) {
	      return false;
	    }
	  }
}