module.exports = function(grunt) {
	//Configure the options for the plugins. Provide the required paths to the tasks.
	grunt.initConfig({
		//Read the package.json to set the application name.
		pkg: grunt.file.readJSON("package.json"),
		//Set the directories.
		dir: {
			webapp: "<%= pkg.name %>",
			dist: "node_modules"
		},
		//To clean the node_modules folder
		clean: {
			dist: "<%=dir.dist%>"
		},
		//To run the eslint
		eslint: {
			src: ["webapp/**/**.js","!webapp/Component-preload.js", "!webapp/test/**.js"],
			options: {
				//adding config file
				configFile: "conf/eslint.json",	
				//adding custom rules' folder path
				rulePaths: ["conf/rules"],
				format: "node_modules/eslint-improved-checkstyle-formatter",
				//adding output file
				outputFile: "eslintCheckstyleOutput.xml"
			}
		},
		//To run qunit
		qunit: {
			all: {
				options: {
			     outputFile: "qunitCheckstyleOutput.xml",
					timeout: 10000,
					urls: [
						"http://localhost:9090/webapp/test/unit/unitTests.qunit.html"
					]
				}
			}
		},
		connect: {
			options: {
					port: 9090,
					hostname: "*"
				},
			src: {},
			dist: {}
		},
		openui5_connect: {
			src: {
				options: {
					appresources: "."
				}
			}
		},
		//To create the componet-preload.js
		 openui5_preload: {
		 	component: {
		 		options: {
					resources: {
		 				cwd: "webapp",
		 				prefix: "<%=dir.webapp%>",
		 				src: ["**/*.js", "**/*.fragment.html", "**/*.fragment.json", "**/*.fragment.xml", "**/*.view.html",
		 					"**/*.view.json", "**/*.view.xml", "**/*.properties", "!test/**"
		 				]
		 			},
		 			dest: "./webapp"
		 		},
		 		components: "<%=dir.webapp%>"
			}
		},
		//To upload the webapp to the ABAP server.
		nwabap_ui5uploader: {
			options: {
				conn: {
					server: "http://10.35.20.227:8001",
					useStrictSSL: false
				},
				auth: {
					user: "user",
					pwd: "pass"
				}
			},
			upload_build: {
				options: {
					ui5: {
						package: "ZTEST_UI5",
						bspcontainer: "Z_DSE_APP_UI5",
						bspcontainer_text: "Direct Sales Application",
						transportno: "$TR_ID"
					},
					resources: {
						cwd: "webapp",
						src: "**/*.*"
					}
				}
			}
		}
	});

	//Now we will load the npm tasks that we want to execute
	grunt.loadNpmTasks("gruntify-eslint");
	grunt.loadNpmTasks("grunt-openui5");
	grunt.loadNpmTasks("grunt-contrib-clean");
	grunt.loadNpmTasks("grunt-contrib-connect");
	grunt.loadNpmTasks("grunt-contrib-qunit");
	grunt.loadNpmTasks("grunt-nwabap-ui5uploader");
	//Set the build task in order of desired task execution.
	//Now that we have already registered the task, this is where we define the task as default.
	grunt.registerTask("test", ["openui5_connect:src", "qunit"]);
	grunt.registerTask("build", ["eslint", "openui5_preload", "test", "clean"]);
	grunt.registerTask("upload", "nwabap_ui5uploader");
	grunt.registerTask("default", "build");
	
};